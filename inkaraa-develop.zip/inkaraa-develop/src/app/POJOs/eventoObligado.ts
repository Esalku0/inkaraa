export interface objEvento {
    idReserva: number;
    title: string;
    start: string;
}