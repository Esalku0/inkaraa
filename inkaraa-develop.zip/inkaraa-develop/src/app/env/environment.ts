export const secretKey = { secretKey: 'esalkualiaga' };
